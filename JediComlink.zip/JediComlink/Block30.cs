﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace JediComlink
{
    public class Block30 : Block
    {
        public Block30(Block parent, int level)
        {
            Id = 0x30;           
            LongChecksum = false;
            Level = level;
            Parent = parent;
        }

        public override void Load(byte[] codeplug, int offSet)
        {
            Length = codeplug[offSet];
            StartAddress = offSet;
            EndAddress = offSet + Length;

            var bytes = new Span<byte>(codeplug, offSet, Length+2);

            Unknown1 = bytes.Slice(0x02, 2).ToArray();
            Serial = Encoding.ASCII.GetString(bytes.Slice(0x04, 10).ToArray());
            Model = Encoding.ASCII.GetString(bytes.Slice(0x0E, 12).ToArray());
            Unknown2 = bytes.Slice(0x1A, 4).ToArray();
            TimeStamp = new DateTime(2000 + GetDigits(bytes[0x1e]),
                                    GetDigits(bytes[0x1f]),
                                    GetDigits(bytes[0x20]),
                                    GetDigits(bytes[0x21]),
                                    GetDigits(bytes[0x22]),
                                    0);
            Unknown3 = bytes.Slice(0x23, 3).ToArray();
            CodeplugSize = bytes[0x26] * 0x100 + bytes[0x27];

            Block31 = new GenericBlock(this, Level + 1);
            Block31.Load(codeplug, bytes[0x28] * 0x100 + bytes[0x29]);

            Block3D = new Block3D(this, Level + 1);
            Block3D.Load(codeplug, bytes[0x2A] * 0x100 + bytes[0x2B]);

            Block36 = new GenericBlock(this, Level + 1);
            Block36.Load(codeplug, bytes[0x2C] * 0x100 + bytes[0x2D]);

            Block55 = new GenericBlock(this, Level + 1);
            Block55.Load(codeplug, bytes[0x2E] * 0x100 + bytes[0x2F]);

            Block54 = new GenericBlock(this, Level + 1);
            Block54.Load(codeplug, bytes[0x30] * 0x100 + bytes[0x31]);

            Block51 = new GenericBlock(this, Level + 1);
            Block51.Load(codeplug, bytes[0x32] * 0x100 + bytes[0x33]);

            Block33 = new GenericBlock(this, Level + 1);
            Block33.Load(codeplug, bytes[0x34] * 0x100 + bytes[0x35]);

            Block39 = new GenericBlock(this, Level + 1);
            Block39.Load(codeplug, bytes[0x36] * 0x100 + bytes[0x37]);

            Block3B = new GenericBlock(this, Level + 1);
            Block3B.Load(codeplug, bytes[0x38] * 0x100 + bytes[0x39]);

            Block34 = new GenericBlock(this, Level + 1);
            Block34.Load(codeplug, bytes[0x3A] * 0x100 + bytes[0x3B]);

            Block35 = new GenericBlock(this, Level + 1);
            Block35.Load(codeplug, bytes[0x3C] * 0x100 + bytes[0x3D]);

            Block3C = new GenericBlock(this, Level + 1);
            Block3C.Load(codeplug, bytes[0x3E] * 0x100 + bytes[0x3F]);

            Block73 = new GenericBlock(this, Level + 1);
            Block73.Load(codeplug, bytes[0x40] * 0x100 + bytes[0x41]);

            Unknown4 = bytes.Slice(0x42, 10).ToArray();

            BlockB5 = new GenericBlock(this, Level + 1);
            BlockB5.Load(codeplug, bytes[0x4C] * 0x100 + bytes[0x4D]);

            Unknown5 = bytes.Slice(0x4E, 2).ToArray();

        }

        public override string ToString()
        {
            var s = new String(' ', Level * 4);
            var sb = new StringBuilder();
            sb.AppendLine($"Block {Id:X2} Length {Length} Starting At {StartAddress:X4}");
            sb.AppendLine("---------------------");
            sb.AppendLine(s + $"Unknown Bytes: {FormatHex(Unknown1)}");
            sb.AppendLine(s + $"Serial: {Serial}");
            sb.AppendLine(s + $"Model: {Model}");
            sb.AppendLine(s + $"Unknown Bytes: {FormatHex(Unknown2)}");
            sb.AppendLine(s + $"Codeplug Time: {TimeStamp}");
            sb.AppendLine(s + $"Unknown Bytes: {FormatHex(Unknown3)}");
            sb.AppendLine(s + $"Code Plug Size {CodeplugSize}");
            sb.AppendLine(Block31.ToString());
            sb.AppendLine(Block3D.ToString());
            sb.AppendLine(Block36.ToString());
            sb.AppendLine(Block55.ToString());
            sb.AppendLine(Block54.ToString());
            sb.AppendLine(Block51.ToString());
            sb.AppendLine(Block33.ToString());
            sb.AppendLine(Block39.ToString());
            sb.AppendLine(Block3B.ToString());
            sb.AppendLine(Block34.ToString());
            sb.AppendLine(Block35.ToString());
            sb.AppendLine(Block3C.ToString());
            sb.AppendLine(Block73.ToString());
            sb.AppendLine(s + $"Unknown Bytes: {FormatHex(Unknown4)}");
            sb.AppendLine(BlockB5.ToString());
            sb.AppendLine(s + $"Unknown Bytes: {FormatHex(Unknown5)}");
            return sb.ToString();
        }

        private string FormatHex(byte[] data)
        {
            var sb = new StringBuilder();
            var l = 1;
            foreach (var b in data)
            {
                sb.Append(b.ToString("X2"));
                if (l < data.Length) sb.Append(l++ % 16 == 0 ? "\n" : " ");
            }
            return sb.ToString();
        }


        private int GetDigits(byte nibbles)
        {
            return (nibbles >> 4) * 10 + (nibbles & 0x0f);
        }

        public byte[] Unknown1 { get; set; }

        public string Serial { get; set; }

        public string Model { get; set; }

        public byte[] Unknown2 { get; set; }

        public DateTime TimeStamp { get; set; }
        public byte[] Unknown3 { get; set; }

        public int CodeplugSize { get; set; }

        public Block Block31 { get; set; }
        public Block Block3D { get; set; }
        public Block Block36 { get; set; }
        public Block Block55 { get; set; }
        public Block Block54 { get; set; }
        public Block Block51 { get; set; }
        public Block Block33 { get; set; }
        public Block Block39 { get; set; }
        public Block Block3B { get; set; }
        public Block Block34 { get; set; }
        public Block Block35 { get; set; }
        public Block Block3C { get; set; }
        public Block Block73 { get; set; }
        public byte[] Unknown4 { get; set; }
        public Block BlockB5 { get; set; }
        public byte[] Unknown5 { get; set; }


    }
}
