﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace JediComlink
{
    public class Block3D : Block
    {
        public Block3D(Block parent, int level)
        {
            Id = 0x3D;           
            LongChecksum = false;
            Level = level;
            Parent = parent;
        }

        public override void Load(byte[] codeplug, int offSet)
        {
            Length = codeplug[offSet];
            StartAddress = offSet;
            EndAddress = offSet + Length;

            var bytes = new Span<byte>(codeplug, offSet, Length+2);


            Block3E = new Block3E(this, Level + 1);
            Block3E.Load(codeplug, bytes[0x02] * 0x100 + bytes[0x03]);

            UnknownPointer1 = bytes.Slice(0x04, 2).ToArray();

            Block4A = new GenericBlock(this, Level + 1);
            Block4A.Load(codeplug, bytes[0x06] * 0x100 + bytes[0x07]);

            UnknownPointer2 = bytes.Slice(0x08, 2).ToArray();
            UnknownPointer3 = bytes.Slice(0x0A, 2).ToArray();
            UnknownPointer4 = bytes.Slice(0x0C, 2).ToArray();

            BlockA0 = new GenericBlock(this, Level + 1);
            BlockA0.Load(codeplug, bytes[0x0E] * 0x100 + bytes[0x0F]);
        }

        public override string ToString()
        {
            var s = new String(' ', Level * 4);
            var sb = new StringBuilder();
            sb.AppendLine($"Block {Id:X2} Length {Length} Starting At {StartAddress:X4}");
            sb.AppendLine(s + Block3E.ToString());
            sb.AppendLine(s + $"Unknown Pointer: {FormatHex(UnknownPointer1)}");
            sb.AppendLine(s + Block4A.ToString());
            sb.AppendLine(s + $"Unknown Pointer: {FormatHex(UnknownPointer2)}");
            sb.AppendLine(s + $"Unknown Pointer: {FormatHex(UnknownPointer3)}");
            sb.AppendLine(s + $"Unknown Pointer: {FormatHex(UnknownPointer4)}");
            sb.AppendLine(s + BlockA0.ToString());
            return sb.ToString();
        }

        private string FormatHex(byte[] data)
        {
            var sb = new StringBuilder();
            var l = 1;
            foreach (var b in data)
            {
                sb.Append(b.ToString("X2"));
                if (l < data.Length) sb.Append(l++ % 16 == 0 ? "\n" : " ");
            }
            return sb.ToString();
        }

        public Block Block3E { get; set; }
        public byte[] UnknownPointer1 { get; set; }
        public Block Block4A { get; set; }
        public byte[] UnknownPointer2 { get; set; }
        public byte[] UnknownPointer3 { get; set; }
        public byte[] UnknownPointer4 { get; set; }
        public Block BlockA0 { get; set; }

    }
}
