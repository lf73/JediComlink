﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JediComlink
{
    public abstract class Block
    {
        public int Id { get; protected set; }

        public int Length { get; set; }

        public Block Parent { get; set; }

        public List<Block> Children { get; set; }

        public int Level { get; set; }

        public byte[] Bytes { get; set; }

        public int StartAddress { get; set; }

        public int EndAddress { get; set; }

        public bool LongChecksum { get; set; }

        public abstract void Load(byte[] codeplug, int offSet);

        public abstract override string ToString();

    }

}
