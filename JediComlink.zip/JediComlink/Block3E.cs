﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace JediComlink
{
    public class Block3E : Block
    {
        public Block3E(Block parent, int level)
        {
            Id = 0x3E;           
            LongChecksum = false;
            Level = level;
            Parent = parent;
        }

        public override void Load(byte[] codeplug, int offSet)
        {
            Length = codeplug[offSet];
            StartAddress = offSet;
            EndAddress = offSet + Length;

            var bytes = new Span<byte>(codeplug, offSet, Length+2);

            Block3F = new GenericBlock(this, Level + 1);
            Block3F.Load(codeplug, bytes[0x02] * 0x100 + bytes[0x03]);

            Block41 = new GenericBlock(this, Level + 1);
            Block41.Load(codeplug, bytes[0x04] * 0x100 + bytes[0x05]);

            UnknownBytes1 = bytes.Slice(0x06, 3).ToArray();

            Block42 = new GenericBlock(this, Level + 1);
            Block42.Load(codeplug, bytes[0x09] * 0x100 + bytes[0x0A]);

            UnknownBytes2 = bytes.Slice(0x0B, 3).ToArray();

            Block8E = new GenericBlock(this, Level + 1);
            Block8E.Load(codeplug, bytes[0x0E] * 0x100 + bytes[0x0F]);

            Block90 = new GenericBlock(this, Level + 1);
            Block90.Load(codeplug, bytes[0x10] * 0x100 + bytes[0x11]);
        }

        public override string ToString()
        {
            var s = new String(' ', Level * 4);
            var sb = new StringBuilder();
            sb.AppendLine($"Block {Id:X2} Length {Length} Starting At {StartAddress:X4}");
            sb.AppendLine(s + Block3F.ToString());
            sb.AppendLine(s + Block41.ToString());
            sb.AppendLine(s + $"Unknown Bytes: {FormatHex(UnknownBytes1)}");
            sb.AppendLine(s + Block42.ToString());
            sb.AppendLine(s + $"Unknown Bytes: {FormatHex(UnknownBytes2)}");
            sb.AppendLine(s + Block8E.ToString());
            sb.AppendLine(s + Block90.ToString());
            return sb.ToString();
        }

        private string FormatHex(byte[] data)
        {
            var sb = new StringBuilder();
            var l = 1;
            foreach (var b in data)
            {
                sb.Append(b.ToString("X2"));
                if (l < data.Length) sb.Append(l++ % 16 == 0 ? "\n" : " ");
            }
            return sb.ToString();
        }

        public Block Block3F { get; set; }
        public Block Block41 { get; set; }
        public byte[] UnknownBytes1 { get; set; }
        public Block Block42 { get; set; }
        public byte[] UnknownBytes2 { get; set; }
        public Block Block8E { get; set; }
        public Block Block90 { get; set; }

    }
}
