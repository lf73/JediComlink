﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JediComlink
{
    class BlockFactory
    {
        public static Block GetBlock(int offSet, byte[] bytes)
        {


            return null;
        }

    }
}
